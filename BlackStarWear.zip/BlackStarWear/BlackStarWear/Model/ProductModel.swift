//
//  ProductModel.swift
//  BlackStarWear
//
//  Created by Дарья on 27.09.2020.
//

import UIKit

struct ProductModel {
    
    var clotherName: String
    var price: String
    var avatarStringURL: String
    var id: Int
    
}
