//
//  CategoriesModel.swift
//  BlackStarWear
//
//  Created by Дарья on 07.10.2020.
//

import Foundation

//struct CategoriesModel: Decodable {
//    let name: String
//    let sortOrder: Int
//    let imageURL: String
//    let subcategories: [Subcat]
//}
//
//struct Subcat: Decodable{
//    let id: String
//    let name: String
//    let iconImage: String?
//}
