//
//  CategoriesData.swift
//  BlackStarWear
//
//  Created by Дарья on 29.09.2020.
//

import Foundation

struct Subcategories {
    let id: String?
    let name: String?
    let iconImage: String?
}

class CategoriesData {
    let name: String
    let sortOrder: Int
    let imageURL: String
    let subcategories: [Subcategories]?
    
    init?(data: NSDictionary){
        
        guard let name = data["name"] as? String,
            let sortOrder = data["sortOrder"] as? String,
            let imageURL = data["image"] as? String,
            let subcategories = data["subcategories"] as? [Subcategories]
        else { return nil }
        
        self.name = name
        self.sortOrder = Int(sortOrder) ?? 0
        self.imageURL = imageURL
        self.subcategories = subcategories
    }
}

